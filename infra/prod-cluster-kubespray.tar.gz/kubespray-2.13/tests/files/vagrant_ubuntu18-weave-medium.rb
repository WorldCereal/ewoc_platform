$num_instances = 16
$vm_memory ||= 1600
$os = "ubuntu1804"
$network_plugin = "weave"
$kube_master_instances = 1
$etcd_instances = 1
